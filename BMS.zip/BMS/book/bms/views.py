from django.shortcuts import render
from django.http import JsonResponse


def sample1(request):
    return render(request, 'navbar.html')


def sample2(request):
    return render(request, 'login.html')

def sample3(request):
    return render(request,'register.html')


