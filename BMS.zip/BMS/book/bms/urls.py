from django.urls import path, include
from .views import sample1, sample2, sample3


urlpatterns = [
    path('', sample1, name='navbar'),
    path('login.html/', sample2, name='login'),
    path('register.html/',sample3,name='register'),
]
